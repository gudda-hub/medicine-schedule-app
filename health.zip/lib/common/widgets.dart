import 'package:flutter/material.dart';

class AppColor {
  static Color primary = Color(0xFF6F8BEF);
  static Color secondary = Color(0xFFD9DDED);
}
